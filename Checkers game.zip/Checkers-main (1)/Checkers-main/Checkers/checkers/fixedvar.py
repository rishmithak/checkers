import pygame


surface = pygame.Surface((90,90))
surface.set_alpha(90)

width = 720
height = 720
rows = 8
columns = 8

# King Image
king = pygame.transform.scale(pygame.image.load("assets/king.png"), (35, 25))
white_winner = pygame.transform.scale(pygame.image.load("assets/whitehaswon.png"),(600,500))
black_winner = pygame.transform.scale(pygame.image.load("assets/blackhaswon.png"),(600,500))

# Colour codes for UI
red = (255, 0, 0)
white = (255, 255, 255)
black = (52, 45, 44)
black2 = (0, 0, 0)
brown = (241, 235, 214)
light_brown = (188, 189, 60)
dark_brown = (113, 132, 86)
grey = (43, 45, 47)
high_green = (255, 223, 34)

surface.fill(white)
space = int(width / columns)